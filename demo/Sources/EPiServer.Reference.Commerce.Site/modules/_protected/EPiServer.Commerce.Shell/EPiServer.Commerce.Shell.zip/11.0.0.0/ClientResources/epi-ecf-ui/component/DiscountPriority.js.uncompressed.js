require({cache:{
'url:epi-ecf-ui/component/templates/DiscountPriority.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div class=\"epi-listingTopContainer\" data-dojo-attach-point=\"heading\">\r\n        <h1>${resources.heading}</h1>\r\n        <p>${resources.description}</p>\r\n    </div>\r\n    <div data-dojo-attach-point=\"discountList\" data-dojo-type=\"epi-ecf-ui/widget/DiscountList\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/component/DiscountPriority", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-geometry",
    "dojo/topic",
    "dojo/when",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/dependency",
    "epi/shell/ViewSettings",
    "epi/shell/_ContextMixin",
// epi-cms    
    "epi-cms/contentediting/ContentEditingValidator", // in order to display validation messages on the toolbar
// resources
    "dojo/text!./templates/DiscountPriority.html",
    "epi/i18n!epi/cms/nls/commerce.components.discountpriority",
    "epi/i18n!epi/nls/episerver.shared",
// Widgets in the template
    "../widget/MarketingToolbar",
    "../widget/DiscountList"
], function (
    array,
    declare,
    lang,
    domGeometry,
    topic,
    when,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    dependency,
    ViewSettings,
    _ContextMixin,
// epi-cms
    ContentEditingValidator,
// resources
    template,
    resources,
    sharedResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, ContentEditingValidator, _ContextMixin], {
        // summary:
        //      This is the initializer of Discount Priority component.

        resources: resources,

        templateString: template,

        contextTypeName: "epi.cms.contentdata",

        // profile:
        //      Refer the Profile settings, including the right panel toolbar
        profile: null,

        // pinnablePanelVisible: boolean
        //      Save visibility status of right panel toolbar
        _pinnablePanelVisible: false,

        // _backLink: Uri
        //      The Uri to the screen would be navigated when clicking on Close button.
        _backLink: null,

        // _marketingToolbarCommands: Array
        //      Collection of marketing toolbar commands
        _marketingToolbarCommands: [],

        postCreate: function () {
            this.inherited(arguments);

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
            this.contextId = this.contextId || contentRepositoryDescriptors.marketing.roots[0];

            this._marketingToolbarCommands = this._getMarketingToolbarCommands();
            this._setupToolbar();

            this.profile = this.profile || dependency.resolve("epi.shell.Profile");
        },

        startup: function () {
            this.inherited(arguments);

            if (this.discountList.model) {
                this.discountList.model.watch("hasPendingChanges", lang.hitch(this,
                    function (property, oldValue, newValue) {
                        this.toolbar.updateActionButtonStatus(this.toolbar.buttonNames.saveButton, newValue);
                    }
                ));
            }
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this.inherited(arguments);

            this._backLink = data && data.backLink ? data.backLink : { uri: ViewSettings.settings.defaultContext };
            // view has been updated, let's update the discount list to reflect changes
            this.discountList.refresh(true);

            // Set unavailable for marketing toolbar commands when changed to discount priority view
            this._hideMarketingCommands();

            // update the toolbar with the current contextId, so any error message will be displayed on the toolbar
            this.toolbar.update({
                currentContext: { id: this.contextId },
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
                        
            when(this.profile.get("tools")).then(lang.hitch(this, function (settings) {
                if (settings) {
                    // save current panel visibility status
                    this._pinnablePanelVisible = settings.visible;
                }
            }));

            // invisible tool panel
            topic.publish("/epi/layout/pinnable/tools/toggle", false);
        },

        resize: function () {
            // summary:
            //      Overridden to resize the discount list

            this.inherited(arguments);

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);
            var headingSize = domGeometry.getMarginBox(this.heading);

            this.discountList.resize({
                h: this._contentBox.h - toolbarSize.h - headingSize.h,
                w: this._contentBox.w
            });
        },

        _getMarketingToolbarCommands: function () {
            // summary:
            //      Gets the marketing toolbar commands
            // tags:
            //      private
            var listCommands = [],
                commandRegistry = dependency.resolve("epi.globalcommandregistry"),
                commandProviders = commandRegistry.get("epi.commerce.marketingToolbar", true);

            if (commandProviders) {
                array.forEach(commandProviders.providers, function (provider) {
                    if (provider.newCampaignCommand) {
                        listCommands.push(provider.newCampaignCommand);
                    }
                    if (provider.newPromotionCommand) {
                        listCommands.push(provider.newPromotionCommand);
                    }
                });
            }

            return listCommands;
        },

        _setupToolbar: function () {
            var actionButtons = this.toolbar.getActionButtons();
            actionButtons.save.action = lang.hitch(this, this._onSave);
            actionButtons.close.action = lang.hitch(this, this._onClose);

            this.toolbar.add([actionButtons.save, actionButtons.close]);
        },

        _onSave: function () {
            var promise = this.discountList.save();
            promise.then(lang.hitch(this, function (results) {
                var validationErrors = [];
                if (results) {
                    // display error messages on toolbar if any
                    array.forEach(results, function (result) {
                        if (result.successful) {
                            return true; // continue
                        }
                        array.forEach(result.properties, function (propertyError) {
                            validationErrors.push({ severity: this.severity.error, errorMessage: propertyError.validationErrors });
                        }, this);
                    }, this);
                }

                this.setGlobalErrors(validationErrors, null);
            }));
            return promise;
        },

        _onClose: function () {            
            topic.publish("/epi/shell/context/request", this._backLink, { sender: this });
        },

        contextChanged: function (ctx, callerData) {
            // summary:
            //      Function called on context changed
            // tags:
            //      Protected
            topic.publish("/epi/layout/pinnable/tools/toggle", this._pinnablePanelVisible);
        },

        _hideMarketingCommands: function () {
            // summary:
            //      Hide all marketing toolbar commands
            // tags:
            //      private
                
            array.forEach(this._marketingToolbarCommands, function (command) {
                command.set("isAvailable", false);
            });
        }
    });
});