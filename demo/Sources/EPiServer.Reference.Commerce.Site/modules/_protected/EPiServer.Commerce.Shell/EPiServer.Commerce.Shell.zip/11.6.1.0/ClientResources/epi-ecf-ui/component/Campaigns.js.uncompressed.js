﻿define("epi-ecf-ui/component/Campaigns", [
// dojo
    "dojo/_base/declare",
// epi cms
    "epi-cms/asset/HierarchicalList"
],

function (
// dojo
    declare,
// epi cms
    HierarchicalList) {
    // module:
    //      epi-ecf-ui.component.Campaigns

    return declare([HierarchicalList], {
        // summary:
        //      Campaigns component.
        // tags:
        //      public

        postscript: function () {
            // summary: Overridden to remove all commands.
            //
            // tag:
            //      public override

            this.inherited(arguments);
            this.model.set("commands", []);
        },

        setupContextMenu: function () {
            // summary: Set up the context menu. Overridden to not add context menu on the campaign tree gadget.
            //
            // tag:
            //      public override
        }
    });
});