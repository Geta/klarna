﻿define("epi-ecf-ui/contentediting/editors/ReadOnlyCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/topic",

    // dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",
    "dgrid/extensions/ColumnReorder",

    // dijit
    "dijit/form/Button",

    // EPi Framework
    "epi/shell/dgrid/Formatter",

    // epi cms
    "epi-cms/contentediting/editors/CollectionEditor",
    "epi-cms/dgrid/DnD",
    "epi-cms/dgrid/WithContextMenu",

    // commerce
    "./_LanguageRestrictedEditButtonMixin",
    "../../dgrid/_ClickablePathColumnMixin",
    "./_GridWithDropContainerMixin"
],
    function (
        //dojo
        declare,
        domClass,
        topic,

        // dgrid
        Keyboard,
        OnDemandGrid,
        Selection,
        ColumnResizer,
        ColumnReorder,

        // dijit
        Button,

        // EPi Framework
        Formatter,

        // epi cms
        CollectionEditor,
        DnD,
        WithContextMenu,

        // commerce
        _LanguageRestrictedEditButtonMixin,
        _ClickablePathColumnMixin,
        _GridWithDropContainerMixin
    ) {
        return declare([CollectionEditor, _GridWithDropContainerMixin, _LanguageRestrictedEditButtonMixin], {
            // module:
            //      epi-ecf-ui/contentediting/editors/ReadOnlyCollectionEditor
            // summary:
            //      Represents the Read-only editor widget for product's price list.

            changeToView: null,

            gridType: declare([OnDemandGrid, Formatter, Selection, Keyboard, DnD, ColumnResizer, ColumnReorder, WithContextMenu, _ClickablePathColumnMixin]),

            _setupGrid: function () {
                this.inherited(arguments);

                this.grid.set("selectionMode", "none");
            },

            _getGridDefinition: function () {
                // summary:
                //      Returns grid's columns definition.
                // tags:
                //      protected

                var columns = this.inherited(arguments);
                var typeColumn = columns.contentTypeIdentifier;
                if (typeColumn) {
                    typeColumn.className = "epi-columnIcon16x16";
                    typeColumn.label = "";
                }
                return columns;
            }
        });
    });