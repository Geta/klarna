require({cache:{
'url:epi-ecf-ui/component/templates/MarketingOverview.html':"<div>\r\n    <div class=\"epi-marketing-pagetitle\">Marketing</div>\r\n    <div data-dojo-attach-point=\"toolbarContainer\" class=\"epi-viewHeaderContainer epi-localToolbar clearfix\"></div>\r\n    <div data-dojo-attach-point=\"leftPaneContainer\" class=\"epi-marketing__leftPane\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/CampaignItemList\" data-dojo-attach-point=\"campaignItemList\"></div>\r\n</div>"}});
define("epi-ecf-ui/component/MarketingOverview", [
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",
    "dijit/registry",
// epi
    "epi/shell/_ContextMixin",
    "epi/shell/widget/SearchBox",
    "../widget/FacetGroupList",
    "../widget/MarketingToolbar",
    "../widget/viewmodel/MarketingFacetGroupViewModel",
    "../widget/viewmodel/MarketingFacetGroupListViewModel",
// resources
    "dojo/text!./templates/MarketingOverview.html",
    "epi/i18n!epi/cms/nls/commerce.components.marketing",
// Widgets in the template
    "../widget/CampaignItemList"
], function (
    declare,
    domGeometry,
    when,
// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,
    _Registry,
// epi
    _ContextMixin,
    SearchBox,
    FacetGroupList,
    MarketingToolbar,
    MarketingFacetGroupViewModel,
    MarketingFacetGroupListViewModel,    
// resources
    template,
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin], {
        // summary:
        //      This is the initializer of Marketing Overview.

        templateString: template,
        resources: resources,

        postCreate: function () {
            this._toolbar = new MarketingToolbar({
                viewName: "marketingoverview"
            });
            this.own(this._toolbar);
            this._toolbar.placeAt(this.toolbarContainer);

            this.searchBox = new SearchBox({
                "class": "epi-search--full-width",
                placeHolder: resources.searchplaceholder,
                triggerChangeOnEnter: false,
                region: "leading"
            });
            this.own(this.searchBox,
                this.searchBox.on("searchBoxChange", this._onFilterChanged.bind(this)));

            this._toolbar.addChild(this.searchBox);
            
            var campaignFacetSettings = {
                itemViewModelClass: MarketingFacetGroupViewModel,
                listViewModelClass: MarketingFacetGroupListViewModel
            };
            this._campaignFacet = new FacetGroupList(campaignFacetSettings);
            this.own(
                this._campaignFacet,
                this.campaignItemList.on("campaignlistupdate", this._campaignFacet.refresh.bind(this._campaignFacet))
            );

            this._campaignFacet.placeAt(this.leftPaneContainer);

            this.clearFilter();
            this.inherited(arguments);
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this._toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            this.inherited(arguments);

            var toolbarSize = domGeometry.getMarginBox(this._toolbar.domNode),
                leftPaneSize = domGeometry.getMarginBox(this.leftPaneContainer);

            var contentHeight = this._contentBox.h - (toolbarSize.t + toolbarSize.h);
            domGeometry.setContentSize(this._campaignFacet.domNode, { h: contentHeight});

            // Set the size of the marketing overview to be the content height minus the toolbar height and width minus the facet width.
            this.campaignItemList.resize({
                h: contentHeight,
                w: this._contentBox.w - leftPaneSize.w
            });
        },

        startup: function () {
            this.inherited(arguments);
            when(this.getCurrentContext(), this.contextChanged.bind(this));
        },

        contextChanged: function (ctx, callerData) {
            this._toolbar.update({
                currentContext: ctx
            });
        },

        _onFilterChanged: function (filter) {
            this.defer(function () {
                this._campaignFacet._onSelectionChanged({ "id": "name", items: [filter.trim()] });
            }.bind(this), 500);
        },

        clearFilter: function() {
            this._campaignFacet._onSelectionChanged({ "id": "name", items: [] });
        },
    });
});