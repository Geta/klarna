define("epi-ecf-ui/contentediting/editors/PricingOverviewEditor", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/when",

    // DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/selector",
    "dgrid/extensions/ColumnResizer",

    // EPi
    "epi/dependency",
    "epi/shell/dgrid/_EditorMetadataMixin",

    //epi-CMS
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",

    // epi commerce
    "./_OverviewEditorBase",
    "../viewmodel/PricingOverviewEditorModel",
    "./SaleCodeEditor",
    "./MoneyEditor",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    // Dojo
    array,
    declare,
    lang,
    aspect,
    domConstruct,
    when,

    // DGrid
    OnDemandGrid,
    Selection,
    selector,
    ColumnResizer,

    // EPi
    dependency,
    _EditorMetadataMixin,

    //epi-CMS
    WithContextMenu,
    formatters,

    // epi commerce
    _OverviewEditorBase,
    PricingOverviewEditorModel,
    SaleCodeEditor,
    MoneyEditor,

    // Resources
    resources,
    messageResources
) {
    return declare([_OverviewEditorBase], {

        grid: null,

        modelType: PricingOverviewEditorModel,

        itemType: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.PriceModel",

        activeEditor: null,

        includedColumns: ["Name", "Code", "MarketId", "PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        editableColumns: ["PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        editorGrid: null,

        storeKey: "epi.commerce.price",

        title: resources.commands.title,

        _noDataMessage: resources.nodatamessage,

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function () {
            // Set up metadata capable grid type
            this.editorGrid = declare([OnDemandGrid, Selection, _EditorMetadataMixin, ColumnResizer, WithContextMenu], {

                _filterProperties: function (properties, include) {
                    // Summary:
                    //      This is overridden to be able to handle rendering of complex type properties in
                    //      the grid. In our case it is a DateTimeRange object.

                    var result = this.inherited(arguments);
                    array.some(result, function (property) {
                        if (property.uiType === null && property.properties.length > 0) {
                            //When we find a property without any ui type and it has properties
                            //we know that we want to render it as a form.
                            property.uiType = "epi-ecf-ui/widget/NewPrice";
                            var metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
                            property.settings = {
                                metadata: metadataManager.getMetadataForType(property.modelType)
                            };
                            return true;
                        }
                    }, this);
                    return result;
                }
            });

            this._setMarkets();
            this.inherited(arguments);
        },

        _setupEvents: function (grid) {
            var customerPriceGroupType = 2;
            this.own(grid,
                grid.on("dgrid-editor-show", function (e) {
                    if (e.editor instanceof SaleCodeEditor) {
                        //The salecode editor should be updated according to what priceType has been set
                        e.editor.showDropDown(e.cell.row.data.priceType === customerPriceGroupType);
                    } else if (e.editor instanceof MoneyEditor) {
                        e.editor.setCurrencySelections(e.cell.row.data.marketId);
                    }
                    this.activeEditor = e.editor;
                    this._showEditorInPopup(e);
                }.bind(this)),
                grid.on("dgrid-datachange", function (e) {
                    //invalid value / validation error will result in no changes to the price row
                    if (this.activeEditor && this.activeEditor.isValid && !this.activeEditor.isValid()) {
                        e.preventDefault();
                    }
                }.bind(this)),
                grid.on(".epi-iconContextMenu:click", this.onContextMenuClick.bind(this)),
                this.model.watch("contentLink", this._changeGridQuery.bind(this)),
                this.model.watch("priceCode", this._changeGridQuery.bind(this)),
                this.model.watch("marketId", this._changeGridQuery.bind(this)),
                this.model.on("itemAdded", grid.refresh.bind(grid)),
                this.model.on("itemsRemoved", grid.refresh.bind(grid)),
                // Listen remove command event
                this.model.on("removeCommandEvent", function () {
                    // Show confirmation dialog to confirm delete price item
                    when(this._showConfirmation(resources.deleteconfirmation.pricetitle, resources.deleteconfirmation.pricedescription), function () {
                        if (this.model) {
                            return this.model.removeItems([this.selectedRecord]);
                        }
                    }.bind(this));
                }.bind(this)),
                this.model.on("duplicateCommandEvent", function () {
                    if (this.selectedRecord && this.model) {
                        // Clone the model and remove its ID so that JsonRest understands this is a new object
                        // and not an attempt to update an existing object
                        var clone = lang.clone(this.selectedRecord);
                        delete clone.id;

                        this.model.addItem(clone);
                    }
                }.bind(this))
            );
        },

        _showEditorInPopup: function (e) {
            //we're wrapping the editor in a div to give it a popup styling.
            var popupElement = domConstruct.create("div", { "class": "epi-dgrid-popup" }, e.cell.element, "last");
            var editorWrapper = domConstruct.create("div", { "class": "epi-dgrid-popup__content" }, popupElement, "last");
            domConstruct.place(e.editor.domNode, editorWrapper);
            domConstruct.place(this.currentEditorHtmlValue, e.cell.element, "first");

            // reset the editor's content box so when FormContainer do the layout, it will resize
            // its children based on their actual size, not the specific one, which has the incorrect value.
            e.editor._contentBox = null;

            var beforeBlurHandle = aspect.before(e.editor, "onBlur", function () {
                //we need to move the editor back to the grid before "blur"
                //so that the dgrid/editor plugin can do its save/"hide editor" magic

                //move the editor to a temporary div first to prevent issues in IE
                //when we move the editors domNode as the only child to e.cell.element
                var tempDiv = domConstruct.create("div");
                domConstruct.place(e.editor.domNode, tempDiv);
                //then move it as the only child to the element we're editing.
                domConstruct.place(e.editor.domNode, e.cell.element, "only");
                beforeBlurHandle.remove();
            });
        },

        _setMarkets: function () {
            if (!this.get("markets")) {
                var marketStore = dependency.resolve("epi.storeregistry").get("epi.commerce.market");
                marketStore.query().then(function (marketList) {
                    this.set("markets", marketList);
                }.bind(this));
            }
        },

        _setMarketIdAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("marketId", value);
        },

        _setPriceCodeAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("priceCode", value);
        },

        addPrice: function (newPrice) {
            // summary:
            //      Add new price to the grid
            // tags:
            //      protected

            // Set default value for marketId column
            var markets = this.get("markets");
            if (!newPrice.marketId && markets && markets.length > 0) {
                var defaultMarket = markets[0];
                newPrice = lang.mixin(newPrice, {
                    marketId: defaultMarket.id,
                    currency: defaultMarket.currencies[0].value
                });
            }

            // Insert new row in grid then edit
            return this.model.addItem(newPrice);
        }
    });
});
