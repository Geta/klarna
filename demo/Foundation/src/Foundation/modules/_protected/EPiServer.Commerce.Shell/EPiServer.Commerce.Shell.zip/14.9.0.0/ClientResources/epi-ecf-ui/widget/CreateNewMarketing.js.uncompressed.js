define("epi-ecf-ui/widget/CreateNewMarketing", [
    // Dojo
    "dojo/_base/declare",
    "dijit/registry",
    // Dijit
    "dijit/layout/_LayoutWidget",

    // EPi Framework
    "epi/shell/command/builder/DropDownButtonBuilder",
    "epi/shell/command/builder/MenuAssembler",
    "epi-cms/widget/command/CreateContentFromSelector",
    "../MarketingUtils"
],

function (
    // Dojo
    declare,
    registry,
    // Dijit
    _LayoutWidget,

    // EPi Framework
    DropDownButtonBuilder,
    MenuAssembler,
    CreateContentFromSelector,
    MarketingUtils
) {

    return declare([_LayoutWidget], {
        // summary:
        //      A widget to display creating new marketing content dropdown.
        //
        // tags:
        //      internal

        buildRendering: function () {
            // summary:
            //      Set 2 commands for creating new campaign and promotion.
            // tags:
            //      private

            this.inherited(arguments);

            this.newCampaignCommand = new CreateContentFromSelector({
                creatingTypeIdentifier: MarketingUtils.contentTypeIdentifier.salesCampaign
            });
            this.newPromotionCommand = new CreateContentFromSelector({
                creatingTypeIdentifier: MarketingUtils.contentTypeIdentifier.promotionData
            });
            
            var listCommand = [];
            listCommand.push(this.newCampaignCommand);
            listCommand.push(this.newPromotionCommand);
            this._set("commands", listCommand);

            this._bindDropdown(listCommand);
        },

        _bindDropdown: function (commands) {
            // summary:
            // tags:
            //      private

            // destroy all menu commands
            this.destroyDescendants();

            if (!commands || commands.length < 1) {
                return;
            }
            var dropDownId = "epi_marketing_dropdown";
            var dropdown = new DropDownButtonBuilder({
                settings: {
                    label: "Create New...",
                    dropDownPosition: ["below-alt"], // align dropdown menu open on the left of the button
                    id: registry.getUniqueId(dropDownId)
                }
            });

            new MenuAssembler({ configuration: [{ builder: dropdown, target: this}], commandSource: this }).build();
        },

        getCommands: function () {
            // summary:
            //      Get commands with confirmation.
            // tags:
            //      public

            return this.get("commands");
        }
    });
});
