define("epi-forms/RetentionPolicyService", [// dojo
"dojo/_base/declare", "dojo/Stateful", // epi
"epi/shell/DestroyableByKey", "epi/dependency", // epi-cms
"epi-cms/_ContentContextMixin"], function ( // dojo
declare, Stateful, // epi
DestroyableByKey, dependency, // epi-cms
_ContentContextMixin) {
  return declare([Stateful, DestroyableByKey, _ContentContextMixin], {
    // summary:
    //      manipulate retention policy data for notification
    // tags:
    //      internal
    store: null,
    postscript: function postscript() {
      this.inherited(arguments);
      var registry = dependency.resolve("epi.storeregistry");
      this.store = this.store || registry.get("epi-forms.retentionpolicy");
    },
    getNotificationMessage: function getNotificationMessage(contentLink) {
      // summary:
      //      Get retention policy notification message
      // tags:
      //      public
      return this.store.executeMethod("GetNotificationMessage", contentLink);
    }
  });
});