define("epi-forms/contentediting/editors/ChoiceWithClearableSelectionEditor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/Deferred", "dojo/_base/array", "dojo/dom-style", // dijit
"dijit/form/Button", // epi-addons
"epi-forms/contentediting/editors/ChoiceWithEditor", // resources
"epi/i18n!epi/cms/nls/episerver.forms.editview"], function ( // dojo
declare, lang, Deferred, array, domStyle, // dijit
Button, // epi-addons
ChoiceWithEditor, // resources
res) {
  // module:
  //      epi-forms/contentediting/editors/ChoiceWithClearableSelectionEditor
  // summary:
  //      Extend ChoiceWithEditor to add Reset button for clearing selection.
  // tags:
  //      internal
  return declare([ChoiceWithEditor], {
    _itemWidgetsLoadedDefer: null,
    _resetButton: null,
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this._itemWidgetsLoadedDefer = new Deferred();
      this.inherited(arguments);
      this._resetButton = new Button({
        label: res.resetconnecteddatasource,
        onClick: lang.hitch(this, function () {
          this.onFocus(); // need this to make the editor start editing

          this.set("value", null);
          this.onChange(this.value);
          this.onBlur(); // for stop editing and create undo step
          // Clear the selector combobox value

          var selectors = this.get("itemWidgets");
          array.forEach(selectors, lang.hitch(this, function (selector) {
            if (selector._extendedWidget) {
              // Set the value of the extended widget (combobox) to empty.
              // Here we pass _recordFieldSeparator to ensure the value format.
              selector.set("extendedWidgetValue", {
                value: this._recordFieldSeparator
              });
              selector._calculateSelectorValue && selector._calculateSelectorValue();
            }
          }));
        })
      });

      this._itemWidgetsLoadedDefer.then(lang.hitch(this, function (itemWidgets) {
        this._resetButton.startup();

        this._resetButton.placeAt(this.domNode, "last");

        domStyle.set(this._resetButton.domNode, {
          marginTop: "10px",
          "float": "right"
        });
      }));
    },
    _setupItemWidget: function _setupItemWidget(
    /*Object*/
    itemWidget) {
      // tags:
      //      override
      this.inherited(arguments); // Resolve _itemWidgetsLoadedDefer when all selectors have been loaded

      if (this._itemWidgets.length === this.selections.length) {
        this._itemWidgetsLoadedDefer.resolve(this._itemWidgets);
      }
    },
    _setReadOnlyAttr: function _setReadOnlyAttr(value) {
      this._resetButton.setDisabled(value);
    }
  });
});