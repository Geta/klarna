define("epi-forms/contentediting/editors/ContentAreaEditor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/topic", "dojo/aspect", "dojo/when", // epi
"epi-cms/contentediting/editors/ContentAreaEditor", "epi-cms/core/ContentReference", "epi/shell/TypeDescriptorManager", // epi-addons
"epi-forms/ModuleSettings", "epi-forms/widget/_ContentAreaMixin", "epi-forms/widget/command/CreateContentFromSelector", "epi-forms/contentediting/ContentAreaViewModel"], function ( // dojo
declare, lang, topic, aspect, when, // epi
ContentAreaEditor, ContentReference, TypeDescriptorManager, // epi-addons
ModuleSettings, _ContentAreaMixin, CreateContentFromSelector, ContentAreaViewModel) {
  // module:
  //      epi-forms/contentediting/editors/ContentAreaEditor
  // summary:
  //
  // tags:
  //      public
  return declare([ContentAreaEditor, _ContentAreaMixin], {
    // summary:
    //     Flag to indicate the widget is closed or not
    _isClosed: null,
    modelClass: ContentAreaViewModel,
    // =======================================================================
    // Overrided stubs
    // =======================================================================
    postMixInProperties: function postMixInProperties() {
      this.inherited(arguments);

      if (this.model) {
        lang.mixin(this.model, new this.modelClass());
      }

      if (this.treeModel && this.treeModel.newItem) {
        this.own(aspect.around(this.treeModel, "newItem", lang.hitch(this, this._aroundNewItem)), aspect.after(this.treeModel, "newItem", lang.hitch(this, function () {
          // raise onDndEnd event when completely create new element and add to ContentArea
          this.tree.dndController.onDndEnd();
        })));
      }
    },
    postCreate: function postCreate() {
      this.inherited(arguments);
      this._isClosed = false;

      if (this.parent && this.overlayItem) {
        this.own(this.connect(this.parent, "onCancel", lang.hitch(this, function () {
          this._isClosed = true;
        })), this.connect(this.parent, "onStopEdit", lang.hitch(this, function () {
          this._isClosed = true;
        })));
      }
    },
    buildRendering: function buildRendering() {
      // tags:
      //      public, extensions
      this.inherited(arguments);

      if (this._dndTarget.onDropData.after) {
        this._dndTarget.onDropData.after.remove();
      }

      this.own(aspect.after(this._dndTarget, "onDropData", lang.hitch(this, this._onDropData), true));
    },
    executeAction: function executeAction(
    /*String*/
    actionName,
    /*Object*/
    itemData) {
      // summary:
      //      Overridden mixin class executing click actions from textWithLinks widget
      // actionName: [String]
      //      Action name of link on content area
      // itemData: [Object]
      //
      // tags:
      //      public, extensions
      var command = null;

      if (actionName === ModuleSettings.createNewFormsElementByDndActionName) {
        // HACK: Preventing the onBlur from being executed so the editor wrapper keeps this editor in editing state
        this._preventOnBlur = true; // since we're going to create a block, we need to hide all validation tooltips because onBlur is prevented here

        this.validate(false);
        command = this._getCreateNewFormsBlockCommand(itemData);
      }

      if (actionName === ModuleSettings.createNewFormsElementActionName) {
        // HACK: Preventing the onBlur from being executed so the editor wrapper keeps this editor in editing state
        this._preventOnBlur = true; // since we're going to create a block, we need to hide all validation tooltips because onBlur is prevented here

        this.validate(false);
        command = this._getCreateNewBlockCommand();
      }

      if (!command) {
        return;
      }

      command.set("model", {
        save: lang.hitch(this, function (block) {
          this._preventOnBlur = false;
          var value = lang.clone(this.get("value"), true) || [];
          value.push(block);
          this.set("value", value); // In order to be able to add a block when creating it from a floating editor
          // we need to set the editing parameter on the editors parent wrapper to true
          // since it has been set to false while being suspended when switching to
          // the secondaryView.

          this.parent.set("editing", true);
          this.onChange(value); // Now call onBlur since it's been prevented using the _preventOnBlur flag.

          this.onBlur();
        }),
        cancel: lang.hitch(this, function () {
          this._preventOnBlur = false;
          this.onBlur();
        })
      });
      command.execute();
    },
    // =======================================================================
    // Private stubs
    // =======================================================================
    _aroundNewItem: function _aroundNewItem(original) {
      // summary:
      //      Modifies Dnd data before send it to tree's model 'epi-cms/contentediting/editors/_ContentAreaTreeModel' newItem() function.
      //      Modified data includes:
      //          contentLink - content reference identification of a newly created form element
      //          name - content name of a newly created form element
      // original: [Object]
      //      Original function - 'newItem(args, parent, insertIndex, before)'
      // tags:
      //      private
      var self = this;
      return lang.hitch(this, function (args, parent, insertIndex, before) {
        if (ModuleSettings.quickLayout && args && args.dndData && args.dndData.data && !args.dndData.data.contentLink) {
          when(self.getCurrentContent(), lang.hitch(this, lang.hitch(this, function (contentData) {
            when(self._getElementTypeId(args.dndData.data.typeIdentifier), lang.hitch(this, function (typeId) {
              when(self.model._getMetadata(contentData.contentLink, typeId), lang.hitch(this, function (metadata) {
                var regroupMetadata = self.model._regroupProperties(metadata);

                if (self.model._hasRequiredProperties(regroupMetadata)) {
                  // HACK: Preventing the onBlur from being executed so the editor wrapper keeps this editor in editing state
                  self._preventOnBlur = true; // since we're going to create a new content, we need to hide all validation tooltips because onBlur is prevented here

                  self.validate(false);
                  var addToDestination = {
                    save: function save(content) {
                      // summary:
                      //  execution after new content is created
                      // content: [Object]
                      //  new content
                      self._preventOnBlur = false; // if current editor is already closed, then delegate the work

                      if (self._isClosed) {
                        return self.overlayItem && self.overlayItem.model.modify(function () {
                          self.overlayItem.model.addChild(content, insertIndex);
                        });
                      }

                      args.dndData.data.contentLink = content.contentLink;
                      args.dndData.data.name = content.name;
                      return original.apply(self.tree.model, [args, parent, insertIndex, before]);
                    },
                    cancel: function cancel() {
                      // summary:
                      //  execution when create new content command is cancelled
                      self.cancel();
                    }
                  };

                  self._createContentWithRequiredProp(typeId, args.dndData.data.typeIdentifier, contentData, addToDestination);
                } else {
                  when(self._getElementByType(typeId, contentData.contentLink), lang.hitch(this, function (contentLink) {
                    var contentWithoutVersion = new ContentReference(contentLink).createVersionUnspecificReference().toString();
                    when(self.contentDataStore.get(contentWithoutVersion), lang.hitch(this, function (content) {
                      args.dndData.data.contentLink = contentWithoutVersion;
                      args.dndData.data.name = content.name;
                      return original.apply(this.tree.model, [args, parent, insertIndex, before]);
                    }));
                  }));
                }
              }));
            }));
          })));
        } else {
          return original.apply(this.tree.model, [args, parent, insertIndex, before]);
        }
      });
    },
    _onDropData: function _onDropData(
    /*Array*/
    data,
    /*Object*/
    source,
    /*Array*/
    nodes,
    /*Boolean*/
    isCopy) {
      // summary:
      //      onDropData handler for the source.
      // data: [Array]
      //      Data extracted from the dragged items.
      // source: [Object]
      //      The source that the drag event originated from.
      // nodes: [Array]
      //      The nodes being dragged.
      // isCopy: [Boolean]
      //      Flag indicating whether the drag is a copy. False indicates a move.
      // tags:
      //      private
      var itemData = data instanceof Array && data[0],
          self = this;

      if (itemData && itemData.options && itemData.options.createNew === true) {
        if (ModuleSettings.quickLayout) {
          when(self.getCurrentContent(), lang.hitch(this, function (contentData) {
            when(self.model._getMetadata(contentData.contentLink, itemData.options.contentTypeId), lang.hitch(this, function (metadata) {
              var regroupMetadata = self.model._regroupProperties(metadata); // If the content has any required properties then go to CreateContent view


              if (self.model._hasRequiredProperties(regroupMetadata)) {
                // HACK: Preventing the onBlur from being executed so the editor wrapper keeps this editor in editing state
                self._preventOnBlur = true; // since we're going to create a new content, we need to hide all validation tooltips because onBlur is prevented here

                self.validate(false);

                self._createContentWithRequiredProp(itemData.options.contentTypeId, itemData.data.typeIdentifier, contentData, self);
              } else {
                when(self._getElementByType(itemData.options.contentTypeId, contentData.contentLink), function (contentLink) {
                  when(self.contentDataStore.get(contentLink), function (content) {
                    self.model.modify(function () {
                      self.model.addChild(content);
                    }); // create the content tree if not exist

                    if (!self.tree) {
                      self._createTree();
                    }
                  });
                });
              }
            }));
          }));
        } else {
          self.executeAction(ModuleSettings.createNewFormsElementByDndActionName, itemData);
        }

        return;
      }

      self.model.modify(function () {
        self.model.addChild(itemData.data);
      });
    },
    _getCreateNewBlockCommand: function _getCreateNewBlockCommand() {
      // summary:
      //
      // returns: [Object]
      //
      // tags:
      //      private
      return new CreateContentFromSelector({
        allowedTypes: this.allowedTypes,
        createAsLocalAsset: true,
        creatingTypeIdentifier: ModuleSettings.formElementBaseContentType,
        restrictedTypes: this.restrictedTypes
      });
    },
    _getCreateNewFormsBlockCommand: function _getCreateNewFormsBlockCommand(
    /*Object*/
    itemData) {
      // summary:
      //
      // itemData: [Object]
      //
      // returns: [Object]
      //
      // tags:
      //      private
      return new CreateContentFromSelector({
        allowedTypes: this.allowedTypes,
        createAsLocalAsset: true,
        creatingTypeIdentifier: itemData.data.typeIdentifier,
        contentTypeId: itemData.options.contentTypeId,
        restrictedTypes: this.restrictedTypes
      });
    },
    save: function save(content) {
      // summary:
      //  execution after new content is created
      // content: [Object]
      //  new content
      var self = this;
      self._preventOnBlur = false; // if current editor already closed, then delegate the work

      if (self._isClosed) {
        if (self.overlayItem) {
          self.overlayItem.model.modify(function () {
            self.overlayItem.model.addChild(content);
          });
        }
      } else {
        var value = lang.clone(self.get("value"), true) || [];
        value.push(content);
        self.set("value", value);
        self.onChange(value);
      }

      self.onBlur();
    },
    cancel: function cancel() {
      // summary:
      //  execution when create new content command is cancelled
      this._preventOnBlur = false;
      this.onBlur();
    },
    _createContentWithRequiredProp: function _createContentWithRequiredProp(typeId, typeIdentifier, parent, addToDestination) {
      // summary:
      //   delegate to CMS to create new content
      topic.publish("/epi/shell/action/changeview", "epi-forms/contentediting/CreateContent", null, {
        contentTypeId: typeId,
        requestedType: typeIdentifier,
        parent: parent,
        addToDestination: addToDestination,
        createAsLocalAsset: true,
        view: TypeDescriptorManager.getValue(typeIdentifier, "createView"),
        autoPublish: true,
        allowedTypes: this.allowedTypes,
        restrictedTypes: this.restrictedTypes,
        showAllProperties: false
      });
    }
  });
});