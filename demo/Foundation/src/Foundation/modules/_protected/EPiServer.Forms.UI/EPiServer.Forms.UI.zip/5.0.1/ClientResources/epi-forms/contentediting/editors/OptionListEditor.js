define("epi-forms/contentediting/editors/OptionListEditor", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", "dojo/dom-class", // epi-addons
"epi-forms/contentediting/editors/CollectionEditor"], function ( // dojo
array, declare, lang, domClass, // epi-addons
CollectionEditor) {
  // module:
  //      epi-forms/contentediting/editors/OptionListEditor
  // summary:
  //      Option list editor widget
  // tags:
  //      public
  return declare([CollectionEditor], {
    // isMultiSelect: [public] Boolean
    //      If TRUE, allow user set checked properties for multi items otherwise only 1 item can be set checked.
    isMultiSelect: true,
    // =======================================================================
    // Overrided stubs
    // =======================================================================
    buildRendering: function buildRendering() {
      this.inherited(arguments);
      domClass.add(this.domNode, "epi-forms-optionList");
    },
    onExecuteDialog: function onExecuteDialog() {
      // summary:
      //      Override this method to modify behaviour when user select checked/unchecked for radio button list.
      // tags:
      //      protected, extensions
      var item = this._itemEditor.get("value"); // If not allow multi select, update checked properties for each item if editing item is set as checked


      if (!this.isMultiSelect && item.checked) {
        array.forEach(this.model.get("items"), function (existingItem, i) {
          if (existingItem.checked && i != this._editingItemIndex) {
            existingItem.checked = false;
            this.model.saveItem(existingItem, i);
          }
        }, this);
      }

      this._editingItemIndex !== undefined ? this.model.saveItem(item, this._editingItemIndex) : this.model.addItem(item);
    },
    _onToggleItemEditor: function _onToggleItemEditor(item, index) {
      this.inherited(arguments);

      var self = this,
          descendantWidgets = this._dialog.content.form._getDescendantFormWidgets(),
          captionWidget = this._getWidgetByNameFromCollection(descendantWidgets, "caption"),
          valueWidget = this._getWidgetByNameFromCollection(descendantWidgets, "value");

      if (!captionWidget || !valueWidget) {
        return;
      }

      this._dialog.own(captionWidget.on("change", function (evt) {
        if (valueWidget.getValue().length == 0) {
          var value = this.getValue();

          if (value) {
            valueWidget.setValue(this.getValue());

            self._dialog.onActionPropertyChanged({
              name: self._dialog._okButtonName
            }, "disabled", false);
          }
        }
      }), captionWidget.on("keyup", lang.hitch(self, self._onKeyUpHandler, captionWidget, valueWidget)), valueWidget.on("keyup", lang.hitch(self, self._onKeyUpHandler, captionWidget, valueWidget)));
    },
    _setDialogConfirmActionStatus: function _setDialogConfirmActionStatus(
    /*Object*/
    item) {
      // summary:
      //      Sets dialog's buttons status.
      // item: [Object]
      //      Option item data object
      // tags:
      //      protected, extensions
      var disabled = !item || item.caption == "" || item.caption.trim() == "" || item.value == "" || item.value.trim() == "";

      this._dialog.onActionPropertyChanged({
        name: this._dialog._okButtonName
      }, "disabled", disabled);
    },
    _getWidgetByNameFromCollection: function _getWidgetByNameFromCollection(widgets, name) {
      var filterList = array.filter(widgets, function (widget) {
        return widget.name == name;
      });
      return filterList.length > 0 ? filterList[0] : null;
    },
    _onKeyUpHandler: function _onKeyUpHandler(captionWidget, valueWidget) {
      var item = {
        caption: captionWidget.getValue(),
        value: valueWidget.getValue()
      };

      this._setDialogConfirmActionStatus(item);
    }
  });
});