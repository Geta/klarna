require({cache:{
'url:epi-find/widget/templates/BestbetGridRow.html':"<div class=\"epi-bestbet-grid-row\">\n    <h3 data-dojo-attach-point=\"titleNode\"></h3>\n    <span data-dojo-attach-point=\"descriptionNode\"></span>\n    <p><a data-dojo-attach-point=\"urlNode\" class=\"epi-visibleLink\"></a></p>\n    <div class=\"epi-vertical-spacer\" data-dojo-attach-point=\"phrasesNode\" title=\"${i18n.fields_bestbetPhrase}\"></div>\n</div>"}});
define("epi-find/widget/BestbetGridRow", [
        "dojo/_base/declare",
        "dojo/_base/array",
        "dojo/dom-attr",
        "dojo/dom-class",

        "dijit/_WidgetBase",
        "dijit/_TemplatedMixin",

        "dojo/text!./templates/BestbetGridRow.html",
        "dojo/i18n!./nls/Bestbets",
        "dojo/on"
    ],
    function(declare,
             array,
             domAttr,
             domClass,
             _WidgetBase,
             _TemplatedMixin,
             template,
             i18n,
             on
        ) {
        return declare([_WidgetBase, _TemplatedMixin], {
            i18n: i18n,

            templateString: template,

            _setTitleAttr: {node: "titleNode", type: "innerHTML"},

            _setDescriptionAttr: {node: "descriptionNode", type: "innerHTML" },

            _setUrlAttr: function(url) {
                this.urlNode.innerHTML = url || "";
                var rxA = /\/(global|content|site)assets\//;
                var rxIsHtm = /\.(html?)$/i;

                //set no href if the url points to an asset, if it is of htm(l) extension
                if( !rxA.test(url) || !rxIsHtm.test(url) ) {
                  domAttr.set(this.urlNode, "href", url || "#");
                }
            },

            _setPhrasesAttr: function(phrases) {
                domClass.toggle(this.phrasesNode, "epi-hidden", !phrases);
                this.phrasesNode.innerHTML = phrases ? array.map(phrases.split(","), function(phrase) {
                    return "<span class=\"epi-tag epi-lozenge\">" + phrase + "</span>";
                }).join("") : "";
            },

            postCreate: function(){
              var url = this.urlNode.innerText;
              var rxA = /\/(global|content|site)assets\//;
              var rxIsHtm = /\.(html?)$/i;

              //attach onclick if url points to an asset, with htm(l) extension
              if( rxA.test(url) && rxIsHtm.test(url) ) {
                on(this.urlNode, "click", function(event) {
                  var w = window.open();
                  var b = w.document.body;
                  var xhrArgs = {
                    url: url,
                    handleAs: "text",
                    load: function(data) {
                      b.innerHTML = data;
                    },
                    error: function(error) {
                      b.innerHTML = "An unexpected error occurred: " + error;
                    }
                  };
                  var deferred = dojo.xhrGet(xhrArgs);
                });
              }
          }
        });
    });
