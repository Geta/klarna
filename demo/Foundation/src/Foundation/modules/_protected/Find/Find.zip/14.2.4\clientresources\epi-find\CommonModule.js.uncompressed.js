﻿define("epi-find/CommonModule", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/store/Memory",
    "epi/routes",
    "epi/dependency",
    "epi/shell/store/JsonRest",
    "epi/shell/store/Registry",
    "epi/shell/store/Throttle",
    "epi/shell/TypeDescriptorManager",

    "epi-cms/ApplicationSettings",
    "epi-cms/store/CustomQueryEngine",

    "./ConfigModel",
    "epi-cms/contentediting/ContentHierarchyService",
    "epi-cms/ContentRepositoryDescriptorService"
],
    function(
            array,
            declare,
            config,
            Memory,
            routes,
            dependency,
            JsonRest,
            Registry,
            Throttle,
            TypeDescriptorManager,
            ApplicationSettings,
            CustomQueryEngine,
            ConfigModel,
            ContentHierarchyService,
            ContentRepositoryDescriptorService
        ) {


        var CommonModule = declare([], {
            // _initialized: bool
            //      Indicates that the initialization is complete
            _initialized: false,

            initialize: function() {
                if (this._initialized) {
                    return;
                }

                this.registerRoutes();

                this.createStores();

                if (!dependency.exists("epi.shell.Profile")) {
                    dependency.register("epi.shell.Profile", {contentLanguage: "en"});
                }
                // TODO: Why do we need to not need these? :s
                dependency.register("epi.shell.MessageService", null);
                dependency.register("epi.ModuleManager", null);
                //dependency.register("epi.commerce.global", {get: function(){return {watch: function() {}};}});
                dependency.register("epi.cms.contentRepositoryDescriptors", new ContentRepositoryDescriptorService(ConfigModel.getValue("repository_descriptors") || config.find.defaultDescriptors));
                dependency.register("epi.cms.ContentHierarchyService",  new ContentHierarchyService());

                TypeDescriptorManager.initialize();

                this._initialized = true;
            },

            registerRoutes: function() {
                var shellRoutes = {
                    "routeBasePath": config.find.siteModulesBaseUrl + "{moduleArea}/{controller}/{action}/{id}",
                    "routeDefaults": {
                        "action": "Index",
                        "id": "",
                        "moduleArea": "Shell"
                    }
                };
                routes.registerRoute(shellRoutes.routeBasePath, shellRoutes.routeDefaults);

                var findRoutes = {
                    "routeBasePath": config.find.siteModulesBaseUrl + "{moduleArea}/{controller}/{action}/{id}",
                    "routeDefaults": {
                        "action": "Index",
                        "id": "",
                        "moduleArea": "Find"
                    }
                };
                routes.registerRoute(findRoutes.routeBasePath, findRoutes.routeDefaults);
            },

            createStores: function() {
                var registry = new Registry();
                // Prepare a providers list based on default configuration or "searchProviders" configuration value
                var providers = config.find.defaultSearchProviders,
                    configuredProviders = ConfigModel.getValue("searchProviders"), providersMap = {};
                if (configuredProviders && configuredProviders.length) {
                    array.forEach(providers, function(provider) {
                        providersMap[provider.searchArea] = provider;
                    });
                    array.forEach(configuredProviders, function(provider) {
                        if (!provider || !provider.settings) {
                            return;
                        }
                        provider.settings.fullName = provider.settings.fullName || provider.settings.FullName;
                        if (!providersMap[provider.searchArea] ||
                            (provider.settings.fullName && provider.settings.fullName.indexOf(".Find") > 0)) { // prefer Find based providers
                            providersMap[provider.searchArea] = provider;
                        }
                    });
                    providers = [];
                    for (var provider in providersMap) {
                        if (providersMap.hasOwnProperty(provider)) {
                            providers.push({searchArea: provider, id: providersMap[provider].settings.fullName});
                        }
                }
                }
                // Create a combined search provider
                var pageAndFilesProviders = array.filter(providers,
                        function(item) { return (item.searchArea === "CMS/pages" || item.searchArea === "CMS/files"); }
                    ).sort(function(item1, item2) { // sort it so that pages goes before files
                        return item1.searchArea > item2.searchArea ? -1 : 1;
                    });
                var combinedProvider = {
                    searchArea: "CMS/pages&files",
                    id: array.map(pageAndFilesProviders, function(item) {return item.id;}).join()
                };
                providers.push(combinedProvider);

                // Create mock search providers store with Find providers
                var searchProvidersStore = new Memory({
                    data: providers
                });
                registry.add("epi.shell.searchproviders", searchProvidersStore);

                // Create search results store
                registry.create("epi.shell.searchresults", routes.getRestPath({ moduleArea: "find", storeName: "searchresults" }));

                registry.create("epi.shell.uidescriptor", routes.getRestPath({ moduleArea: "find", storeName: "finduidescriptor" }));
                var contentStoreName = ConfigModel.getValue("api.best_bets.content_store_name") || "content";
                registry.create("epi.cms.content.light", routes.getRestPath({ moduleArea: "find", storeName: contentStoreName}), { idProperty: "contentLink", queryEngine: CustomQueryEngine });
                registry.add("epi.cms.contentdata", {}); // this store is required by some components but not needed by the ContentSelector.
                registry.add("epi.cms.contenttype", {get: function() {}}); // this store is required by some components related to ContentSelector.

                registry.add("epi.cms.content.search",
                    new Throttle(
                        new JsonRest({
                            target: routes.getRestPath({ moduleArea: "find", storeName: contentStoreName }),
                            idProperty: "contentLink"
                        })
                    ));
                registry.add("epi.commerce.relation", {}); // this store is required by Commerce selector.

                dependency.register("epi.storeregistry", registry);
                }
        });

        var module = new CommonModule();
        return module;
    }
);
