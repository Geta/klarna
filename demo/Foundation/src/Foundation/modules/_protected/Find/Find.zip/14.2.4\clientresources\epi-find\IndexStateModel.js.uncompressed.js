﻿define("epi-find/IndexStateModel", [
    "../dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/topic",
    "dojo/when",
    "./ConfigModel",
    "dojo/i18n!./widget/nls/IndexStateModel"
], function (
    config,
    declare,
    lang,
    Stateful,
    topic,
    when,
    ConfigModel,
    i18n
    ) {
    var IndexState = declare([Stateful], {

            // maxDocumentsInIndex: Number
            //      Limit of maximal documents count that can be saved in the index
            maxDocumentsInIndex: null,
            _maxDocumentsInIndexSetter: function(value) {
                this.maxDocumentsInIndex = value;
                this._verifyDocumentsCount();
            },

            // documentsInIndex: Number
            //      Current documents count in the index
            documentsInIndex: null,
            _documentsInIndexSetter: function(value) {
                this.documentsInIndex = value;
                this._verifyDocumentsCount();
            },

            // showWarningOnAndBelow: Number
            //      Percentage of index filling when a warning message is shown. The message can be ignored and closed by the user.
            showWarningOnAndBelow: 10,
            // showPermanentWarningOnAndBelow: Number
            //      Percentage of index filling when a warning message is shown and can not be closed by the user.
            showPermanentWarningOnAndBelow: 5,
            // showErrorOnAndBelow: Number
            //      Percentage of index filling when an error message is shown and can not be closed by the user.
            showErrorOnAndBelow: 0,

            init: function() {
                // summary:
                //      Initialize the model
                ConfigModel.watch("config", lang.hitch(this, function(name, oldValue, value) {
                    this.set("maxDocumentsInIndex", value.max_docs);
                }));
            },

            refresh: function() {
                // summary:
                //      Refresh all model parameters
                this.refreshMaxDocumentsInIndex();
                this.refreshDocumentsInIndex();
            },

            refreshDocumentsInIndex: function() {
                // summary:
                //      Refreshes documents count in the index by issuing a server request
                var countStore = config.dependencies["epi-find.ElasticsearchStore"];
                when(countStore.query({size:0}).total, lang.hitch(this, function(total) {
                    this.set("documentsInIndex", total);
                }));
            },

            refreshMaxDocumentsInIndex: function() {
                // summary:
                //      Refreshes maximal documents count in the index by refreshing the configuration
                ConfigModel.refresh();
            },

            _verifyDocumentsCount: function() {
                // summary:
                //      This method verifies if index is filled above certain limits and issues a notification message if needed.
                if (!this.maxDocumentsInIndex || !this.documentsInIndex) {
                    return;
                }
                var percentageLeft = this.percentageLeft = Math.max(Math.round((this.maxDocumentsInIndex-this.documentsInIndex)*100 / this.maxDocumentsInIndex), 0),
                    notification = {topic: "global", key: "IndexLimit"};

                if (percentageLeft > this.showWarningOnAndBelow) {
                    notification.type = "clear";
                    notification.message = null;
                }
                else if (percentageLeft > this.showPermanentWarningOnAndBelow) {
                    notification.type = "warning";
                    notification.message = this._getWarning();
                }
                else if (percentageLeft > this.showErrorOnAndBelow) {
                    notification.type = "warning";
                    notification.message = this._getWarning();
                    notification.persistent = true;
                }
                else {
                    notification.type = "error";
                    notification.message = this._getError();
                    notification.persistent = true;
                }
                topic.publish("epi/notification", notification);
            },

            _getWarning: function() {
                // summary:
                //      Creates a notification message parametrised with index filling percentage and "upgrade your account" link.
                return lang.replace(i18n.indexLimitReaching, {percent: this.percentageLeft, link: config.find.orderFindUrl});
            },

            _getError: function() {
                // summary:
                //      Creates a notification message parametrised with "upgrade your account" link.
                return lang.replace(i18n.indexLimitReached, {link: config.find.orderFindUrl});
            }
        }
    );
    var indexState = new IndexState(); // this model is a singleton.
    return indexState;
});
