﻿define("epi-find/Application", [
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/window",
    "dojo/query",
    "dojo/dom-attr",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/router",
    "dojo/hash",
    "dojo/topic",
    "dojo/Deferred",

    "dojox/mvc/at",

    //"fastclick",

    "./store/StoreFactory",
    "./widget/SiteMenu",
    "./widget/SiteMenuModel",

    "./ConfigModel",
    "./IndexStateModel",

    "epi-saas-base/NotificationHandler",
    "epi-saas-base/_PropagatingDestroyableMixin",

    "./CommonModule",

    "./manage/ManageController",
    "./configure/ConfigureController",
    "./overview/OverviewController",
    "./borrowed/epi/shell/customFocusIndicator", // "borrowed" from epi/shell/customFocusIndicator

    "epi-saas-base/XhrJsonPatch!",
    "./AccessRestrictions!"
],
function(
    config,
    declare,
    lang,
    win,
    query,
    domAttr,
    domClass,
    domConstruct,
    domStyle,
    router,
    hash,
    topic,
    Deferred,
    at,
    //fastclick,
    StoreFactory,
    SiteMenu,
    SiteMenuModel,
    ConfigModel,
    IndexStateModel,
    NotificationHandler,
    _PropagatingDestroyableMixin,

    CommonModule,
    ManageController,
    ConfigureController,
    OverviewController
    ) {

    var Application = declare([_PropagatingDestroyableMixin], {
        // summary:
        //          Application code for Find.

        views: null,

        // rootNode: DomNode
        //      This is the root node for the application passed from the bootstrapper
        rootNode: null,

        // siteMenu: /widget/SiteMenu
        //      the menu where the user can change Site and Language
        siteMenu: null,

        // siteMenuModel: epi-find/widget/SiteMenuModel
        //      Model for the site menu
        siteMenuModel: null,

        // defaultView: String
        //      View that should be activated by default
        defaultView: config.intents.view.statistics,

        startup: function () {
            var self = this;
            var initDeferred = new Deferred();
            this.rootNode = config.rootNode || document.getElementById("applicationContainer");

            config.dependencies = {};

            var controllerContainer = domConstruct.create("div", {});

            this.siteMenuModel = new SiteMenuModel();
            this.own(this.siteMenuModel);

            this.siteMenu = new SiteMenu({
                helpContainer: controllerContainer,
                showHelp: at(this.siteMenuModel, "showHelp"),

                sites: at(this.siteMenuModel, "sites"),
                selectedSite: at(this.siteMenuModel, "selectedSite"),
                sitesDisabled: at(this.siteMenuModel, "sitesDisabled"),

                languages: at(this.siteMenuModel, "languages"),
                selectedLanguage: at(this.siteMenuModel, "selectedLanguage"),
                languagesDisabled: at(this.siteMenuModel, "languagesDisabled")
            });
            this.siteMenu.placeAt(this.rootNode);
            this.siteMenu.startup();
            this.own(this.siteMenu);

            IndexStateModel.init();
            StoreFactory.authToken = config.find.token;
            // start configuration load and when config is loaded, init CommonModule and indicate initialization complete
            ConfigModel.target =  config.find.siteConfigUrl || config.find.siteServiceApiBaseUrl + "config/";

            ConfigModel.refresh().then(function(configuration) {
                StoreFactory.createStores();
                CommonModule.initialize();
                IndexStateModel.refreshDocumentsInIndex();
                initDeferred.resolve();
            });

            // Initializing generic notifications
            var notificationHandler = new NotificationHandler({
                rootNode: this.rootNode
            });
            notificationHandler.startup();
            this.own(notificationHandler);

            domClass.add(controllerContainer, "epi-controllerContainer");
            domConstruct.place(controllerContainer, this.rootNode);

            this.views = {
                manage: {
                    name: "manage",
                    controller: new ManageController(this, controllerContainer)
                },
                configure: {
                    name: "configure",
                    controller: new ConfigureController(this, controllerContainer)
                },
                overview: {
                    name: "overview",
                    controller: new OverviewController(this, controllerContainer)
                }
            };

            this.own(this.views.manage.controller);
            this.own(this.views.configure.controller);
            this.own(this.views.overview.controller);

            config.dependencies["epi-find.ManageController"] = this.views.manage.controller;
            config.dependencies["epi-find.ConfigController"] = this.views.configure.controller;
            config.dependencies["epi-find.OverviewController"] = this.views.overview.controller;

            this.own(router.register(".*", function(event) {
                self._onHashUpdate(event);
            }));

            this._registerIntents(config.intents);
            initDeferred.then(function(){
                router.startup();
                self.own(
                    self.siteMenuModel.watch("selectedLanguage", function(name, oldValue, newValue) {
                        if (newValue) {
                            self._refreshView();
                        }
                    }),
                    self.siteMenuModel.watch("selectedSite", function(name, oldValue, newValue) {
                        if (newValue) {
                            self._refreshView();
                        }
                    }));
            });

            // Redirect to statistics view if hash is not set
            hash(location.hash || this.defaultView, true);

            // Mobile stuff
            //query("head").append("<link rel=\"apple-touch-icon-precomposed\" href=\"" + config.packages[0].location + "/images/apple-touch-icon-precomposed.png\" />");
            // this.FastClick = new FastClick(win.body());
        },

        _registerIntents: function(intents) {
            for(var i in intents) {
                var intent = intents[i];
                if (intent instanceof Object) {
                    this._registerIntents(intent);
                    continue;
                }
                topic.subscribe(intent, this._newIntentTrigger(intent));
            }
        },

        _newIntentTrigger: function(intent) {
            var self = this;
            return function(params) {
                var queryString = self._paramsToQuery(params);
                router.go(intent + (queryString.length > 0 ? "?" + queryString : ""));
            };
        },

        _paramsToQuery: function(object) {
            var result = [];
            for (var key in object) {
                result.push(key + "=" + encodeURIComponent(object[key]));
            }
            return result.join("&");
        },

        _onHashUpdate: function(event) {
            var path = event.newPath;

            var action = this.getActionFromPath(path);
            var context = action.actions.shift();

            var activated = this._activateView(context, action);

            if (!activated)
            {
                // TODO: Show a proper 404-page
                console.error("Error: Unmapped route!");
                console.error(event);
                console.error(action);

                // Revert the hash to previous value or go to a default view as a workaround until we have 404 pages
                if (event.oldPath) {
                    hash(event.oldPath);
                }
                else {
                    router.go(this.defaultView);
                }
            }
        },

        _toggleEnabledOptions: function(actionString) {
            var sitesDisabled = actionString.indexOf(config.intents.view.synonyms) !== -1 ||
                actionString.indexOf(config.intents.view.connectors) !== -1 ||
                actionString.indexOf(config.intents.view.boosting) !== -1 ||
                actionString.indexOf(config.intents.view.index) !== -1 ||
                actionString.indexOf(config.intents.view.explore) !== -1;
            this.siteMenuModel.set("sitesDisabled", sitesDisabled);

            var languagesDisabled = actionString.indexOf(config.intents.view.connectors) !== -1 ||
                actionString.indexOf(config.intents.view.boosting) !== -1 ||
                actionString.indexOf(config.intents.view.index) !== -1 ||
                actionString.indexOf(config.intents.view.overview) !== -1 ||
                actionString.indexOf(config.intents.view.explore) !== -1;
            this.siteMenuModel.set("languagesDisabled", languagesDisabled);
        },

        getActionFromPath: function(hash) {
            var result = {};

            var questionMarkPosition = hash.indexOf("?") === -1 ? hash.length : hash.indexOf("?"),
                rawQuery = hash.substring(questionMarkPosition + 1, hash.length);

            result.actions = hash.substring(0, questionMarkPosition).split("/");
            result.params = this._queryToParams(rawQuery);

            return result;
        },

        _queryToParams: function(rawQuery) {
            var result = {};
            if (rawQuery.length === 0) {
                return result;
            }
            var pairs = rawQuery.split("&");
            for(var i in pairs) {
                var keyvalue = pairs[i].split("=");
                result[keyvalue[0]] = keyvalue[1];
            }
            return result;
        },

        _activateView: function (context, action) {
            var view;
            for(var controllerName in this.views) {
                if (controllerName === context) {
                    view = this.views[controllerName];
                    break;
                }
            }
            if (!view) {
                return false;
            }

            var activeView = this.activeView;
            if (view !== activeView) {
                this._deactivateView(activeView);
            }
            this.activeView = view;

            if (view.name) {
                this._setActiveMenuItem(view.name);
            }

            if (view.controller) {
                view.controller.startup();
                view.controller.takeAction(action.actions, action.params);
                view.controller.show();

                // toggle enabled options using resolved current actions
                if (view.controller.currentAction) {
                    this._toggleEnabledOptions(view.name + "/" + view.controller.currentAction);
                }
                else {
                    // trying to toggle enabled options using original action values if current action is unknown
                    var actions = action && action.actions && action.actions.length > 0 ?
                        "/" + action.actions.join("/") :
                        "";
                    this._toggleEnabledOptions(view.name + actions);
                }
            }
            this.siteMenu.refresh();

            return true;
        },

        _refreshView: function() {
            if (this.activeView) {
                this.activeView.controller.refresh();
            }
        },

        _deactivateView: function (view) {
            this._setActiveMenuItem(null);
        },

        _setActiveMenuItem: function (viewName) {
            // summary: highlights active menu item in the global menu since the menu itself does not support hash tag based navigation
            var subMenu = query("#global_find_sub");
            var menuItems = query("li > a", subMenu[0]);
            menuItems.forEach(function (node) {
                var currentItemUrl = domAttr.get(node, "href");
                if (viewName && currentItemUrl.indexOf("#" + viewName) !== -1) {
                    domClass.add(node.parentNode, "epi-navigation-selected");
                } else {
                    domClass.remove(node.parentNode, "epi-navigation-selected");
                }
            });
        }
    });

    var application = new Application();
    application.startup();
    return application;
});
