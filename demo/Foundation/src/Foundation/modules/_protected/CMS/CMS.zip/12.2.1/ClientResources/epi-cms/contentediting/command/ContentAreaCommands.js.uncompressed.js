define("epi-cms/contentediting/command/ContentAreaCommands", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/Stateful",
    "dijit/Destroyable",
    "epi-cms/ApplicationSettings",
    "./BlockRemove",
    "./BlockEdit",
    "./BlockInlineEdit",
    "./MoveVisibleToPrevious",
    "./MoveVisibleToNext",
    "./Personalize",
    "./SelectDisplayOption",
    "./MoveOutsideGroup"
], function (array, declare, Stateful, Destroyable, ApplicationSettings, Remove, Edit, InlineEdit, MoveVisibleToPrevious, MoveVisibleToNext, Personalize, SelectDisplayOption, MoveOutsideGroup) {

    return declare([Stateful, Destroyable], {
        // tags:
        //      internal

        commands: null,

        constructor: function () {
            this._commandSpliter = this._commandSpliter || new Stateful({
                category: "menuWithSeparator"
            });
            this.commands = [
                new Edit({ category: null }),
                new InlineEdit(),
                this._commandSpliter,
                new SelectDisplayOption(),
                new MoveVisibleToPrevious(),
                new MoveVisibleToNext(),
                new Remove()
            ];
            // Only add personalize command if the ui is not limited
            if (!ApplicationSettings.limitUI) {
                this.commands.splice(3, 0, new Personalize({ category: null }), new MoveOutsideGroup());
            }

            this.commands.forEach(function (command) {
                this.own(command);
            }, this);
        },

        _modelSetter: function (model) {
            this.model = model;

            array.forEach(this.commands, function (command) {
                command.set("model", model);
            });
        }
    });
});
